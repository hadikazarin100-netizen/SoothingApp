package com.example.soothingapp.ui.theme

import android.app.Activity
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary          = Color(0xFF4A9B8E),
    onPrimary        = Color.White,
    primaryContainer = Color(0xFFD4E9F7),
    secondary        = Color(0xFF9B8EC4),
    background       = Color(0xFFE8E0F5),
    surface          = Color(0xFFFAFAFF),
    onBackground     = Color(0xFF3A3560),
    onSurface        = Color(0xFF3A3560),
)

@Composable
fun SoothingAppTheme(content: @Composable () -> Unit) {
    val colorScheme = LightColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color(0xFFE8E0F5).toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = true
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content     = content
    )
}
