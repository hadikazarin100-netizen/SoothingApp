package com.example.soothingapp

import android.media.MediaPlayer
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ─── Soothing Messages ────────────────────────────────────────────────────────

val soothingMessages = listOf(
    "Take a deep breath.\nYou are exactly where you need to be.",
    "Let go of what you cannot control.\nEmbrace the peace within.",
    "This moment is yours.\nBreathe slowly, feel the calm.",
    "You are safe.\nAll is well in this moment.",
    "Rest your mind.\nNature is breathing with you.",
    "Be still.\nThe storm always passes."
)

// ─── Color Palette ─────────────────────────────────────────────────────────────

val SoftLavender    = Color(0xFFE8E0F5)
val PastelBlue      = Color(0xFFD4E9F7)
val PastelGreen     = Color(0xFFD6EFE2)
val MutedPurple     = Color(0xFF9B8EC4)
val DeepTeal        = Color(0xFF4A9B8E)
val SoftWhite       = Color(0xFFFAFAFF)
val TextDark        = Color(0xFF3A3560)

// ─── SoothingScreen Composable ────────────────────────────────────────────────

@Composable
fun SoothingScreen() {
    val context = LocalContext.current

    // State
    var currentMessage by remember { mutableStateOf(soothingMessages[0]) }
    var isPlaying     by remember { mutableStateOf(false) }
    var mediaPlayer   by remember { mutableStateOf<MediaPlayer?>(null) }
    var textAlpha     by remember { mutableStateOf(1f) }

    // Continuous gentle pulse for the button
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val buttonScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue  = 1.04f,
        animationSpec = infiniteRepeatable(
            animation  = tween(1800, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "buttonScale"
    )

    // Animated alpha for fade-in text
    val animatedAlpha by animateFloatAsState(
        targetValue   = textAlpha,
        animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
        label         = "textFade"
    )

    // Cleanup MediaPlayer when composable leaves
    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
        }
    }

    // Background gradient (shifts between lavender → pastel blue → pastel green)
    val gradient = Brush.verticalGradient(
        colors = listOf(SoftLavender, PastelBlue, PastelGreen)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient),
        contentAlignment = Alignment.Center
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(40.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp)
        ) {

            // ── App Title ──────────────────────────────────────────────────
            Text(
                text       = "✦  Serenity  ✦",
                fontSize   = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color      = MutedPurple,
                letterSpacing = 4.sp
            )

            // ── Decorative Circle + Icon ───────────────────────────────────
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(140.dp)
                    .background(
                        brush  = Brush.radialGradient(
                            colors = listOf(Color(0xFFD0F0FF), Color(0xFFB8E0FF))
                        ),
                        shape  = RoundedCornerShape(50)
                    )
                    .shadow(
                        elevation = 12.dp,
                        shape     = RoundedCornerShape(50),
                        ambientColor  = MutedPurple.copy(alpha = 0.3f),
                        spotColor     = MutedPurple.copy(alpha = 0.3f)
                    )
            ) {
                Text(text = "🌊", fontSize = 56.sp)
            }

            // ── Soothing Message Card ──────────────────────────────────────
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .alpha(animatedAlpha),
                shape  = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = SoftWhite.copy(alpha = 0.75f)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Text(
                    text      = currentMessage,
                    fontSize  = 20.sp,
                    fontWeight = FontWeight.Light,
                    color     = TextDark,
                    textAlign = TextAlign.Center,
                    lineHeight = 32.sp,
                    modifier  = Modifier.padding(horizontal = 24.dp, vertical = 28.dp)
                )
            }

            // ── Play / Stop Button ─────────────────────────────────────────
            Button(
                onClick = {
                    if (isPlaying) {
                        // ── Stop ──
                        mediaPlayer?.apply {
                            stop()
                            release()
                        }
                        mediaPlayer = null
                        isPlaying   = false
                    } else {
                        // ── Play + change message with fade ──
                        // Fade out → swap message → fade in
                        textAlpha = 0f
                        val nextMessage = soothingMessages
                            .filter { it != currentMessage }
                            .random()
                        currentMessage = nextMessage
                        textAlpha = 1f   // triggers animateFloatAsState fade-in

                        // Play audio — uses R.raw.relaxing_sound
                        // Make sure you have a file named "relaxing_sound.mp3"
                        // inside app/src/main/res/raw/
                        try {
                            mediaPlayer = MediaPlayer.create(context, R.raw.relaxing_sound)
                            mediaPlayer?.apply {
                                isLooping = true
                                start()
                            }
                            isPlaying = true
                        } catch (e: Exception) {
                            // If the audio file is missing, the app still works
                            isPlaying = true
                        }
                    }
                },
                modifier = Modifier
                    .height(58.dp)
                    .fillMaxWidth(0.7f),
                shape  = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPlaying) Color(0xFFB5C9B0) else DeepTeal,
                    contentColor   = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation  = 8.dp,
                    pressedElevation  = 2.dp
                )
            ) {
                Text(
                    text       = if (isPlaying) "⏹  Stop Sound" else "▶  Play Sound",
                    fontSize   = 17.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.sp
                )
            }

            // ── Status hint ───────────────────────────────────────────────
            if (isPlaying) {
                Text(
                    text     = "🎵 Playing relaxing sounds…",
                    fontSize = 13.sp,
                    color    = MutedPurple,
                    fontWeight = FontWeight.Light
                )
            }
        }
    }
}
