# 🌊 Serenity – Soothing App

A minimal, calming Android app built with Kotlin + Jetpack Compose.

---

## 📁 Project Structure

```
SoothingApp/
├── app/
│   ├── build.gradle.kts                          ← App-level Gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/soothingapp/
│       │   ├── MainActivity.kt                   ← App entry point
│       │   ├── SoothingScreen.kt                 ← Main UI + logic
│       │   └── ui/theme/
│       │       └── Theme.kt                      ← Color theme
│       └── res/
│           ├── raw/
│           │   └── relaxing_sound.mp3            ← ⬅ YOU ADD THIS FILE
│           ├── values/
│           │   ├── strings.xml
│           │   └── themes.xml
│           └── mipmap-*/                         ← Auto-generated icons
├── build.gradle.kts                              ← Project-level Gradle
├── settings.gradle.kts
├── gradle.properties
└── gradle/
    └── libs.versions.toml                        ← Dependency catalog
```

---

## 🎵 Step 1 – Add Your Audio File

The app plays a sound file from `res/raw/`. You must add this yourself.

### Where to get a free relaxing sound:
- https://freesound.org  (search "rain", "ocean waves", "forest")
- https://pixabay.com/sound-effects/
- https://soundbible.com

### How to add it:
1. Download any `.mp3` file (rain, ocean, etc.)
2. Rename it exactly to: **`relaxing_sound.mp3`**
3. In Android Studio, right-click on `app/src/main/res/`
4. Choose **New → Android Resource Directory**
5. Set Resource type to **raw** → click OK
6. Drag and drop `relaxing_sound.mp3` into the `res/raw/` folder

> ⚠️ The filename MUST be `relaxing_sound.mp3` (all lowercase, no spaces)
> because it maps to `R.raw.relaxing_sound` in the code.

---

## 🚀 Step 2 – Open in Android Studio

1. Download and install **Android Studio Ladybug** or newer:
   https://developer.android.com/studio

2. Open Android Studio → click **"Open"**

3. Navigate to the `SoothingApp/` folder and click **OK**

4. Wait for Gradle sync to complete (may take 2–5 minutes on first run)

---

## 📱 Step 3 – Run on an Emulator or Device

### Option A – Emulator:
1. In Android Studio, click **Tools → Device Manager**
2. Click **"Create Device"**
3. Choose a phone (e.g., Pixel 6) → choose API 34 → Finish
4. Press the ▶ **Run** button (or Shift+F10)

### Option B – Real Device:
1. On your Android phone, go to **Settings → About Phone**
2. Tap **Build Number** 7 times to enable Developer Options
3. Go to **Settings → Developer Options** → enable **USB Debugging**
4. Connect phone via USB → press ▶ Run in Android Studio

---

## 📦 Step 4 – Build an APK

To generate an installable `.apk` file:

1. In Android Studio, click **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Wait for the build to finish
3. Click **"locate"** in the notification, or find the APK at:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```
4. Transfer this file to your phone and install it
   (Make sure "Install from unknown sources" is enabled on your phone)

---

## ✨ Features

| Feature | Details |
|---|---|
| Background | Soft lavender → pastel blue → pastel green gradient |
| Messages | 6 calming messages, changes randomly on each press |
| Animation | Smooth fade-in when message changes |
| Audio | Loops until you press Stop |
| Button | Toggles between Play ▶ and Stop ⏹ |

---

## 🛠 Troubleshooting

| Problem | Fix |
|---|---|
| Gradle sync fails | File → Invalidate Caches → Restart |
| Sound doesn't play | Make sure `relaxing_sound.mp3` is in `res/raw/` |
| App crashes on launch | Check Logcat (View → Tool Windows → Logcat) |
| Build error about `R.raw` | The raw folder or file is missing/misnamed |

---

## 📋 Requirements

- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 24+ (Android 7.0 Nougat)
- Kotlin 2.0+
- Jetpack Compose BOM 2024.12+
